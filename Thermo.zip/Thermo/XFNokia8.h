/*******************************************************************************
 * XFNokia8.h
 * Generated with XUI Utils (written by Moreno Seri (moreno.seri@gmail.com))
 *
 * - Font: Nokia Cellphone FC, 6pt
 * - Max size: 9x8
 * - Space width: 3
 * - Char range: 0x21 - 0xF9
 * - Bits per pixel: 1
 * - Memory size: 1,33 KB
 *******************************************************************************/

#ifndef XFNokia8_h
#define XFNokia8_h

/// XFNokia8
extern const XFlashData XFNokia8;

#endif
