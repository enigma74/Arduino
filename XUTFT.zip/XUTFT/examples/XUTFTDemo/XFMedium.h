/*******************************************************************************
 * XFMedium.h
 * Generated with XUI Utils (written by Moreno Seri (moreno.seri@gmail.com))
 *
 * - Font: Segoe UI, 16pt, clear type, contrast 4
 * - Max size: 20x22
 * - Space width: 6
 * - Char range: 0x21 - 0xF9
 * - Bits per pixel: 2
 * - Memory size: 4,12 KB
 *******************************************************************************/

#ifndef XFMedium_h
#define XFMedium_h

/// XFMedium
extern const XFlashData XFMedium;

#endif
